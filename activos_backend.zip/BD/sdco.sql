-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         8.0.29 - MySQL Community Server - GPL
-- SO del servidor:              Linux
-- HeidiSQL Versión:             12.1.0.6537
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Volcando estructura de base de datos para db_activo
CREATE DATABASE IF NOT EXISTS `db_activo` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `db_activo`;

-- Volcando estructura para tabla db_activo.sessions
CREATE TABLE IF NOT EXISTS `sessions` (
  `session_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `expires` int unsigned NOT NULL,
  `data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  PRIMARY KEY (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Volcando datos para la tabla db_activo.sessions: ~32 rows (aproximadamente)
INSERT IGNORE INTO `sessions` (`session_id`, `expires`, `data`) VALUES
	('1uiwAGMu9BtMA6ttG8sSsjp7NyBU0CvP', 1666746511, '{"cookie":{"originalMaxAge":86400000,"expires":"2022-10-26T15:08:31.102Z","httpOnly":false,"path":"/"},"id_user":4,"nombre":"Cristian","apellido":"Virago","email":"cristian@gmail.com","id_rol":"admin"}'),
	('3eOaH0kxG4TcE8YZc4mD4X9hxVhTmBId', 1666742672, '{"cookie":{"originalMaxAge":86400000,"expires":"2022-10-26T14:04:31.769Z","httpOnly":false,"path":"/"},"id_user":4,"nombre":"Cristian","apellido":"Virago","email":"cristian@gmail.com","id_rol":"admin"}'),
	('6Da1jIwmFf2JwqVsXfrghg9gYVI12gYD', 1666746010, '{"cookie":{"originalMaxAge":86400000,"expires":"2022-10-26T15:00:09.973Z","httpOnly":false,"path":"/"},"id_user":4,"nombre":"Cristian","apellido":"Virago","email":"cristian@gmail.com","id_rol":"admin"}'),
	('6PwnUloVGmqCybBFgq9kptQDQD392U_3', 1666732960, '{"cookie":{"originalMaxAge":86400000,"expires":"2022-10-26T11:22:39.763Z","httpOnly":false,"path":"/"},"id_user":4,"nombre":"Cristian","apellido":"Virago","email":"cristian@gmail.com","id_rol":"admin"}'),
	('72yHOd4BAK9EFWN1C0Iyvv9kJ0skJuOc', 1666744595, '{"cookie":{"originalMaxAge":86400000,"expires":"2022-10-26T14:36:34.691Z","httpOnly":false,"path":"/"},"id_user":4,"nombre":"Cristian","apellido":"Virago","email":"cristian@gmail.com","id_rol":"admin"}'),
	('8cYF-DQ0ju5FCwrlLIOFMRyoSZ65FtZG', 1666746535, '{"cookie":{"originalMaxAge":86400000,"expires":"2022-10-26T15:08:55.097Z","httpOnly":false,"path":"/"},"id_user":4,"nombre":"Cristian","apellido":"Virago","email":"cristian@gmail.com","id_rol":"admin"}'),
	('BVjdCX3Et4M_uMn6-KgrxAkticVhBKkp', 1666723102, '{"cookie":{"originalMaxAge":86400000,"expires":"2022-10-25T18:38:22.315Z","httpOnly":false,"path":"/"},"id_user":2,"nombre":"felipe","apellido":"munoz","email":"felipe@gmail.com","id_rol":"admin"}'),
	('HPolLrHJxgA-WRcLgomXmsh-7JEatX-n', 1666746536, '{"cookie":{"originalMaxAge":86400000,"expires":"2022-10-26T15:08:55.380Z","httpOnly":false,"path":"/"},"id_user":4,"nombre":"Cristian","apellido":"Virago","email":"cristian@gmail.com","id_rol":"admin"}'),
	('JBajJCg2yllc8Zgyl1v6VfyOr3nB51Iv', 1666745251, '{"cookie":{"originalMaxAge":86400000,"expires":"2022-10-26T14:47:30.697Z","httpOnly":false,"path":"/"},"id_user":4,"nombre":"Cristian","apellido":"Virago","email":"cristian@gmail.com","id_rol":"admin"}'),
	('KEvnEFjon6KM9leKBNZ0CPQVrQnG0RRH', 1666711645, '{"cookie":{"originalMaxAge":86400000,"expires":"2022-10-25T15:27:25.282Z","httpOnly":false,"path":"/"},"id_user":2,"nombre":"felipe","apellido":"munoz","email":"felipe@gmail.com","id_rol":"admin"}'),
	('Kv3kmtg_qKRrz0GaAYf0td4ZcDbAE5of', 1666746745, '{"cookie":{"originalMaxAge":86400000,"expires":"2022-10-26T15:12:24.956Z","httpOnly":false,"path":"/"},"id_user":4,"nombre":"Cristian","apellido":"Virago","email":"cristian@gmail.com","id_rol":"admin"}'),
	('LETDeZAF4HTV3HNeE9vB_waAG5LSVszI', 1666723116, '{"cookie":{"originalMaxAge":86400000,"expires":"2022-10-25T18:38:36.161Z","httpOnly":false,"path":"/"},"id_user":2,"nombre":"felipe","apellido":"munoz","email":"felipe@gmail.com","id_rol":"admin"}'),
	('NCBn132rr75WUkZyyv-B4TdmZKIh0Bma', 1666731509, '{"cookie":{"originalMaxAge":86400000,"expires":"2022-10-26T10:58:28.525Z","httpOnly":false,"path":"/"},"id_user":4,"nombre":"Cristian","apellido":"Virago","email":"cristian@gmail.com","id_rol":"admin"}'),
	('NEDrTpW6e4W-O-zZwmKSa51j5Re78SBe', 1666741075, '{"cookie":{"originalMaxAge":86400000,"expires":"2022-10-26T13:37:54.472Z","httpOnly":false,"path":"/"},"id_user":4,"nombre":"Cristian","apellido":"Virago","email":"cristian@gmail.com","id_rol":"admin"}'),
	('NVEgySJ-LDreXtzeoFuVjL0srltveQev', 1666744896, '{"cookie":{"originalMaxAge":86400000,"expires":"2022-10-26T14:41:36.070Z","httpOnly":false,"path":"/"},"id_user":4,"nombre":"Cristian","apellido":"Virago","email":"cristian@gmail.com","id_rol":"admin"}'),
	('Nsg2sNVJv9OvEVEn7xiUABZasDRfb_Np', 1666747135, '{"cookie":{"originalMaxAge":86400000,"expires":"2022-10-26T15:18:54.815Z","httpOnly":false,"path":"/"},"id_user":4,"nombre":"Cristian","apellido":"Virago","email":"cristian@gmail.com","id_rol":"admin"}'),
	('UObfFoSkkxqUEoqE4Sa9DwMlmX1kcs_D', 1666746535, '{"cookie":{"originalMaxAge":86400000,"expires":"2022-10-26T15:08:54.979Z","httpOnly":false,"path":"/"},"id_user":4,"nombre":"Cristian","apellido":"Virago","email":"cristian@gmail.com","id_rol":"admin"}'),
	('VZXxm5Nyu87GsYoHUAxSXxBPHsH8SNBh', 1666746533, '{"cookie":{"originalMaxAge":86400000,"expires":"2022-10-26T15:08:52.411Z","httpOnly":false,"path":"/"},"id_user":4,"nombre":"Cristian","apellido":"Virago","email":"cristian@gmail.com","id_rol":"admin"}'),
	('ZZ4R8Ik5BksHUEsUhrluDQWOmWCHsfv6', 1666746486, '{"cookie":{"originalMaxAge":86400000,"expires":"2022-10-26T15:08:06.298Z","httpOnly":false,"path":"/"},"id_user":4,"nombre":"Cristian","apellido":"Virago","email":"cristian@gmail.com","id_rol":"admin"}'),
	('ZvL1USE7KpSjFG8HsA-D46j0xOaArz44', 1666747161, '{"cookie":{"originalMaxAge":86400000,"expires":"2022-10-26T15:19:21.367Z","httpOnly":false,"path":"/"},"id_user":4,"nombre":"Cristian","apellido":"Virago","email":"cristian@gmail.com","id_rol":"admin"}'),
	('aLAgFqoN0lPBsNDKlQzzlYei9I1lLdsB', 1666747192, '{"cookie":{"originalMaxAge":86400000,"expires":"2022-10-26T15:19:52.322Z","httpOnly":false,"path":"/"},"id_user":4,"nombre":"Cristian","apellido":"Virago","email":"cristian@gmail.com","id_rol":"admin"}'),
	('bCkhyJqkodXj8E4T7lMgSoXB2uxVOgZV', 1666711642, '{"cookie":{"originalMaxAge":86399999,"expires":"2022-10-25T15:27:16.826Z","httpOnly":false,"path":"/"},"id_user":2,"nombre":"felipe","apellido":"munoz","email":"felipe@gmail.com","id_rol":"admin"}'),
	('bbe9qHdUMql_zfEqaxJc9-dngDnc65ju', 1666746536, '{"cookie":{"originalMaxAge":86400000,"expires":"2022-10-26T15:08:55.272Z","httpOnly":false,"path":"/"},"id_user":4,"nombre":"Cristian","apellido":"Virago","email":"cristian@gmail.com","id_rol":"admin"}'),
	('cjVyBhlguRm5JBWxeHwAIpP4wIBVvb77', 1666746536, '{"cookie":{"originalMaxAge":86400000,"expires":"2022-10-26T15:08:55.541Z","httpOnly":false,"path":"/"},"id_user":4,"nombre":"Cristian","apellido":"Virago","email":"cristian@gmail.com","id_rol":"admin"}'),
	('csvf_hYORA5zn0j2mtSe-8ja6jvqTDNR', 1666723567, '{"cookie":{"originalMaxAge":86400000,"expires":"2022-10-25T18:46:06.595Z","httpOnly":false,"path":"/"},"id_user":4,"nombre":"Cristian","apellido":"Virago","email":"cristian@gmail.com","id_rol":"admin"}'),
	('e1gv505yTth0Kio7WYBhdlwhMVVRLyfs', 1666747111, '{"cookie":{"originalMaxAge":86400000,"expires":"2022-10-26T15:18:30.482Z","httpOnly":false,"path":"/"},"id_user":4,"nombre":"Cristian","apellido":"Virago","email":"cristian@gmail.com","id_rol":"admin"}'),
	('fays1UqaoDNqOSTLYX9skFACGiuGlRub', 1666738288, '{"cookie":{"originalMaxAge":86400000,"expires":"2022-10-26T12:51:28.258Z","httpOnly":false,"path":"/"},"id_user":4,"nombre":"Cristian","apellido":"Virago","email":"cristian@gmail.com","id_rol":"admin"}'),
	('jsr1GBIIUNKQgYKPTnIkRK7XmJ2SXPsa', 1666723574, '{"cookie":{"originalMaxAge":86400000,"expires":"2022-10-25T18:46:14.204Z","httpOnly":false,"path":"/"},"id_user":4,"nombre":"Cristian","apellido":"Virago","email":"cristian@gmail.com","id_rol":"admin"}'),
	('kIMz87UXqoUH94l9fG3Lm7ulPXkanR_7', 1666746535, '{"cookie":{"originalMaxAge":86400000,"expires":"2022-10-26T15:08:54.784Z","httpOnly":false,"path":"/"},"id_user":4,"nombre":"Cristian","apellido":"Virago","email":"cristian@gmail.com","id_rol":"admin"}'),
	('oSJTRrSPAxd49WOgXAzJSygCNPcvodoV', 1666746634, '{"cookie":{"originalMaxAge":86400000,"expires":"2022-10-26T15:10:34.397Z","httpOnly":false,"path":"/"},"id_user":4,"nombre":"Cristian","apellido":"Virago","email":"cristian@gmail.com","id_rol":"admin"}'),
	('waTZJyEmq33WaLqYemsLpnpXrLIBS_0U', 1666723544, '{"cookie":{"originalMaxAge":86400000,"expires":"2022-10-25T18:45:44.128Z","httpOnly":false,"path":"/"},"id_user":4,"nombre":"Cristian","apellido":"Virago","email":"cristian@gmail.com","id_rol":"admin"}'),
	('x3Fab40A4VaVGRJzKJtzRRbIKjYCC98l', 1666746655, '{"cookie":{"originalMaxAge":86400000,"expires":"2022-10-26T15:10:54.535Z","httpOnly":false,"path":"/"},"id_user":4,"nombre":"Cristian","apellido":"Virago","email":"cristian@gmail.com","id_rol":"admin"}');

-- Volcando estructura para tabla db_activo.user
CREATE TABLE IF NOT EXISTS `user` (
  `id_user` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) DEFAULT NULL,
  `apellido` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `rol` varchar(50) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Volcando datos para la tabla db_activo.user: ~2 rows (aproximadamente)
INSERT IGNORE INTO `user` (`id_user`, `nombre`, `apellido`, `email`, `rol`, `password`) VALUES
	(2, 'felipe', 'munoz', 'felipe@gmail.com', 'admin', '$2a$08$0otNnI7sr.axwctVWKQa3u8gp0qwFGL8Ab.bXE13R.mfcfNBMA6fe'),
	(4, 'Cristian', 'Virago', 'cristian@gmail.com', 'admin', '$2a$08$MfGRvyoghBIbLm0eUo0N3eEFwV3YtvP.MclCtos1ojqMOCtjzxhcO');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
