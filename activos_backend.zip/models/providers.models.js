const conexion = require("../config/conexion");

module.exports = {

    addProviders: function (provider, callback) {
        const sql = `INSERT INTO providers (provider) VALUES ('${provider}')`;
        conexion.query(sql, function (err, rows, fields) {
            if (err) throw err;
            else {
                return callback(rows);
            }
        })
    },

    deleteProviders: function (id, callback) {
        const sql = "DELETE FROM providers WHERE id =?";
        conexion.query(sql, id, function (err, rows) {
            if (err) throw err;
            else {
                return callback(rows[0]);
            }
        });
    },

    editProviders: function (
        id, provider, callback) {
        const sql = `UPDATE providers SET
        provider = '${provider}'
                    WHERE id = '${id}'`;
        conexion.query(sql, function (err, rows, fields) {
            if (err) throw err;
            return callback(rows);
        });
    },

    listProviders: function (callback) {
        const sql = "SELECT * FROM providers";
        conexion.query(sql, function (err, data) {
            if (err) throw err;
            return callback(data);
        });
    },

    searchId: function (id, callback) {
        conexion.query(
            "SELECT id FROM providers WHERE id =?",
            [id],
            (err, rows, fields) => {
                if (err) throw err;
                else {
                    return callback(rows[0]);
                }
            }
        );
    },

    searchProvider: function (provider, callback) {
        conexion.query(
            "SELECT provider FROM providers WHERE provider =?",
            [provider],
            (err, rows, fields) => {
                if (err) throw err;
                else {
                    return callback(rows[0]);
                }
            }
        );
    },
    
}