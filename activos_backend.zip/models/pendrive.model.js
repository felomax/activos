const conexion = require("../config/conexion");

module.exports = {


    addPendrive: function (
        restriccion, grado, nombre, apellidos, numero_dispositivo, fecha_entrega, correo, pendrivescol, device_type, hardware_id, serial, version, estado, callback) {
        const sql = `INSERT INTO pendrives (restriccion, grado, nombre, apellidos,numero_dispositivo, fecha_entrega, correo, pendrivescol, device_type, hardware_id, serial,version, estado) VALUES ('${restriccion}','${grado}','${nombre}','${apellidos}','${numero_dispositivo}','${fecha_entrega}','${correo}','${pendrivescol}','${device_type}','${hardware_id}','${serial}','${version}','${estado}')`;
        conexion.query(sql, function (err, rows, fields) {
            if (err) throw err;
            else {
                return callback(rows);
            }
        });
    },

    deletePendrive: function (id, callback) {
        const sql = "DELETE FROM pendrives WHERE id =?";
        conexion.query(sql, id, function (err, rows) {
            if (err) throw err;
            else {
                return callback(rows[0]);
            }
        })
    },

    editPendrive: function (
        id,
        restriccion,
        grado,
        nombre,
        apellidos,
        numero_dispositivo,
        fecha_entrega,
        correo,
        pendrivescol,
        device_type,
        hardware_id,
        serial,
        version,
        estado, callback) {
        const sql = `UPDATE pendrives SET
        restriccion = '${restriccion}',
        grado = '${grado}',
        nombre = '${nombre}',
        apellidos = '${apellidos}',                
        numero_dispositivo = '${numero_dispositivo}',
        fecha_entrega = '${fecha_entrega}',  
        correo = '${correo}',  
        pendrivescol = '${pendrivescol}',  
        device_type = '${device_type}',  
        hardware_id = '${hardware_id}',  
        serial = '${serial}',  
        version = '${version}',                        
        estado = '${estado}'
        WHERE id = '${id}'`;
        conexion.query(sql, function (err, rows, fields) {
            if (err) throw err;
            return callback(rows);
        });
    },



    listPendrives: function (callback) {
        const sql = "SELECT * FROM pendrives";
        conexion.query(sql, function (err, rows) {
            if (err) throw err;
            else {
                return callback(rows);
            }
        });
    },

    searchPendrive: function (numero_dispositivo, callback) {
        conexion.query(
            "SELECT numero_dispositivo FROM pendrives WHERE numero_dispositivo =?",
            [numero_dispositivo],
            (err, rows, fields) => {
                if (err) throw err;
                else {
                    return callback(rows[0]);
                }
            }
        );
    },

    searchId: function (id, callback) {
        conexion.query(
            "SELECT id FROM pendrives WHERE id =?",
            [id],
            (err, rows, fields) => {
                if (err) throw err;
                else {
                    return callback(rows[0]);
                }
            }
        );
    },
}