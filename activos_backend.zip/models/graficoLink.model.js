const conexion = require("../config/conexion");

module.exports ={

    listaGraficaLinks: function (callback){
        const sql = "SELECT * FROM vista_grafica_links";
        conexion.query(sql, function (err, data){
            if (err) throw err;
            return callback (data);
        })
    }
}