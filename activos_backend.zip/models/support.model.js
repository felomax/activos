const conexion = require("../config/conexion");

module.exports = {

    addSupport: function (support_type, support_level, license, callback) {
        const sql = `INSERT INTO support (support_type,support_level,license) VALUES ('${support_type}','${support_level}','${license}')`;
        conexion.query(sql, function (err, rows, fields) {
            if (err) throw err;
            else {
                return callback(rows);
            }
        })
    },

    deleteSupport: function (id, callback) {
        const sql = "DELETE FROM support WHERE id =?";
        conexion.query(sql, id, function (err, rows) {
            if (err) throw err;
            else {
                return callback(rows[0]);
            }
        });
    },

    editSupport: function (
        id, support_type, support_level, callback) {
        const sql = `UPDATE support SET
        support_type = '${support_type}',
        support_level = '${support_level}'
        WHERE id = '${id}'`;
        conexion.query(sql, function (err, rows, fields) {
            if (err) throw err;
            return callback(rows);
        });
    },

    listSupport: function (callback) {
        const sql = "SELECT * FROM support";
        conexion.query(sql, function (err, data) {
            if (err) throw err;
            return callback(data);
        });
    },

    searchId: function (id, callback) {
        conexion.query(
            "SELECT id FROM support WHERE id =?",
            [id],
            (err, rows, fields) => {
                if (err) throw err;
                else {
                    return callback(rows[0]);
                }
            }
        );
    },

    searchSupport: function (support_type, callback) {
        conexion.query(
            "SELECT support_type FROM support WHERE support_type =?",
            [support_type],
            (err, rows, fields) => {
                if (err) throw err;
                else {
                    return callback(rows[0]);
                }
            }
        );
    },

}