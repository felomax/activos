const conexion = require("../config/conexion");

module.exports ={

    listaGraficaNodes: function (callback){
        const sql = "SELECT * FROM vista_grafica_nodes";
        conexion.query(sql, function (err, data){
            if (err) throw err;
            return callback (data);
        })
    }
}