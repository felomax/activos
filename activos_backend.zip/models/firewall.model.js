const conexion = require("../config/conexion");

module.exports = {

    addFirewall: function (
        equipo, model, serial_number, ip_addr, ubicacion, version, connected_to, activation_date, expire_date, license_type, provider, state, callback) {
        const sql = `INSERT INTO firewall (equipo, model, serial_number, ip_addr, ubicacion, version, connected_to, activation_date, expire_date, license_type, provider, state) VALUES ('${equipo}','${model}','${serial_number}','${ip_addr}','${ubicacion}','${version}','${connected_to}','${activation_date}','${expire_date}','${license_type}','${provider}','${state}')`;
        conexion.query(sql, function (err, rows, fields) {
            if (err) throw err;
            else {
                return callback(rows);
            }
        });
    },

    deleteFirewall: function (id, callback) {
        const sql = "DELETE FROM firewall WHERE id =?";
        conexion.query(sql, id, function (err, rows) {
            if (err) throw err;
            else {
                return callback(rows[0]);
            }
        })
    },

    editFirewall: function (
        id, equipo, model, serial_number, ip_addr, ubicacion, version, connected_to, activation_date, expire_date,
        license_type, provider, state, callback) {
        const sql = `UPDATE firewall SET
                    equipo = '${equipo}',
                    model = '${model}',
                    serial_number = '${serial_number}',
                    ip_addr = '${ip_addr}',                
                    ubicacion = '${ubicacion}',
                    version = '${version}',  
                    connected_to = '${connected_to}',  
                    activation_date = '${activation_date}',  
                    expire_date = '${expire_date}',  
                    license_type = '${license_type}',  
                    provider = '${provider}',  
                    state = '${state}'                        
                    WHERE id = '${id}'`;
        conexion.query(sql, function (err, rows, fields) {
            if (err) throw err;
            return callback(rows);
        });
    },

    listFirewall: function (callback) {
        const sql = "SELECT * FROM consulta_equipos";
        conexion.query(sql, function (err, data) {
            if (err) throw err;
            return callback(data);
        })
    },

    searchFirewall: function (equipo, callback) {
        conexion.query(
            "SELECT equipo FROM firewall WHERE equipo =?",
            [equipo],
            (err, rows, fields) => {
                if (err) throw err;
                else {
                    return callback(rows[0]);
                }
            }
        );
    },

    searchId: function (id, callback) {
        conexion.query(
            "SELECT id FROM firewall WHERE id =?",
            [id],
            (err, rows, fields) => {
                if (err) throw err;
                else {
                    return callback(rows[0]);
                }
            }
        );
    },


}