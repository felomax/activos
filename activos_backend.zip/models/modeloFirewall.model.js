const conexion = require("../config/conexion");

module.exports = {


    addModeloF: function (
        modelo, callback) {
        const sql = `INSERT INTO modelo_firewall (modelo) VALUES ('${modelo}')`;
        conexion.query(sql, function (err, rows, fields) {
            if (err) throw err;
            else {
                return callback(rows);
            }
        });
    },


    deleteModeloF: function (id, callback) {
        const sql = "DELETE FROM modelo_firewall WHERE id =?";
        conexion.query(sql, id, function (err, rows) {
            if (err) throw err;
            else {
                return callback(rows[0]);
            }
        })
    },

    editModeloF: function (
        id, modelo, callback) {
        const sql = `UPDATE modelo_firewall SET                    
                    modelo = '${modelo}'                                           
                    WHERE id = '${id}'`;
        conexion.query(sql, function (err, rows, fields) {
            if (err) throw err;
            return callback(rows);
        });
    },

    listModeloF: function (callback) {
        const sql = "SELECT * FROM modelo_firewall";
        conexion.query(sql, function (err, data) {
            if (err) throw err;
            return callback(data);
        })
    },


    searchModeloF: function (modelo, callback) {
        conexion.query(
            "SELECT modelo FROM modelo_firewall WHERE modelo =?",
            [modelo],
            (err, rows, fields) => {
                if (err) throw err;
                else {
                    return callback(rows[0]);
                }
            }
        );
    },

    searchId: function (id, callback) {
        conexion.query(
            "SELECT id FROM modelo_firewall WHERE id =?",
            [id],
            (err, rows, fields) => {
                if (err) throw err;
                else {
                    return callback(rows[0]);
                }
            }
        );
    },

}