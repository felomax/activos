const conexion = require("../config/conexion");

module.exports = {

    addLicenses: function (license, callback) {
        const sql = `INSERT INTO licenses (license) VALUES ('${license}')`;
        conexion.query(sql, function (err, rows, fields) {
            if (err) throw err;
            else {
                return callback(rows);
            }
        })
    },

    deleteLicense: function (id, callback) {
        const sql = "DELETE FROM licenses WHERE id =?";
        conexion.query(sql, id, function (err, rows) {
            if (err) throw err;
            else {
                return callback(rows[0]);
            }
        });
    },

    editLicense: function (
        id, license, callback) {
        const sql = `UPDATE licenses SET
                     license = '${license}'
                    WHERE id = '${id}'`;
        conexion.query(sql, function (err, rows, fields) {
            if (err) throw err;
            return callback(rows);
        });
    },

    listLicenses: function (callback) {
        const sql = "SELECT * FROM licenses";
        conexion.query(sql, function (err, data) {
            if (err) throw err;
            return callback(data);
        });
    },

    searchId: function (id, callback) {
        conexion.query(
            "SELECT id FROM licenses WHERE id =?",
            [id],
            (err, rows, fields) => {
                if (err) throw err;
                else {
                    return callback(rows[0]);
                }
            }
        );
    },

    searchLicense: function (licenses, callback) {
        conexion.query(
            "SELECT license FROM licenses WHERE license =?",
            [licenses],
            (err, rows, fields) => {
                if (err) throw err;
                else {
                    return callback(rows[0]);
                }
            }
        );
    },
    
}