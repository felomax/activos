const conexion = require("../config/conexion");
const pendriveModel = require("../models/pendrive.model");


module.exports = {

    addPendrive: async (req, res) => {
        const restriccion = req.body.restriccion;
        const grado = req.body.grado;
        const nombre = req.body.nombre;
        const apellidos = req.body.apellidos;
        const numero_dispositivo = req.body.numero_dispositivo;
        const fecha_entrega = req.body.fecha_entrega;
        const correo = req.body.correo;
        const pendrivescol = req.body.pendrivescol;
        const device_type = req.body.device_type;
        const hardware_id = req.body.hardware_id;
        const serial = req.body.serial;
        const version = req.body.version;
        const estado = req.body.estado;

        pendriveModel.searchPendrive(numero_dispositivo, function (data) {
            if (data != undefined) {
                return res.status(501).send("Dispositivo ya se encuentra registrado");
            } else {
                pendriveModel.addPendrive(
                    restriccion, grado, nombre, apellidos, numero_dispositivo, fecha_entrega, correo, pendrivescol, device_type, hardware_id, serial, version, estado,
                    function (data) {
                        return res.status(200).send("Equipo registrado con exito");
                    })
            }
        })
    },

    editPendrive: async (req, res) => {
        const id = req.params.id;
        const restriccion = req.body.restriccion;
        const grado = req.body.grado;
        const nombre = req.body.nombre;
        const apellidos = req.body.apellidos;
        const numero_dispositivo = req.body.numero_dispositivo;
        const fecha_entrega = req.body.fecha_entrega;
        const correo = req.body.correo;
        const pendrivescol = req.body.pendrivescol;
        const device_type = req.body.device_type;
        const hardware_id = req.body.hardware_id;
        const serial = req.body.serial;
        const version = req.body.version;
        const estado = req.body.estado;

        pendriveModel.searchId(id, function (data) {
            if (data == undefined) {
                return res.status(501).send("Pendrive no existe")
            } else {
                pendriveModel.editPendrive(id,
                    restriccion, grado, nombre, apellidos, numero_dispositivo, fecha_entrega, correo, pendrivescol, device_type, hardware_id, serial, version, estado,
                    function (data) {
                        res.send(data);
                    }
                )
            }
        })
    },

    deletePendrive: function (req, res) {
        const id = req.params.id;
        pendriveModel.searchId(id, function (data) {
            if (data == undefined) {
                return res.status(501).send("Pendrive No existe")
            } else {
                pendriveModel.deletePendrive(id, function (data) {
                    return res.status(200).send("Pendrive Eliminado con exito");
                })
            }
        })
    },


    listPendrives: function (req, res) {
        pendriveModel.listPendrives(function (data) {
            res.send(data);
        })
    }
}
