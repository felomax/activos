const supportModule = require("../models/support.model")

const conexion = require("../config/conexion");

module.exports = {

    addSupport: async (req, res) => {
        const support_type = req.body.support_type;
        const support_level = req.body.support_level;
        

        supportModule.searchSupport(support_type, function (data) {
            if (data != undefined) {
                return res.status(501).send("Soporte ya Registrada");
            } else {
                supportModule.addSupport(support_type,support_level, function (data) {
                    return res.status(200).send("Soporte registrado con éxito")
                })
            }
        })
    },

    editSupport: async (req, res) => {
        const id = req.params.id;
        const support_type = req.body.support_type;
        const support_level = req.body.support_level;
        
        supportModule.searchId(id, function (data) {
            if (data == undefined) {
                return res.status(501).send("Proveedor no existe")
            } else {
                supportModule.editSupport(
                    id, support_type, support_level,  function (data) {
                        res.send(data);
                    }
                )
            }
        })

    },

    deleteSupport: function (req, res) {
        const id = req.params.id;

        supportModule.searchId(id, function (data) {
            if (data == undefined) {
                return res.status(501).send("Soporte no existe")
            } else {
                supportModule.deleteSupport(id, function (data) {
                    return res.status(200).send("Soporte eliminado con exito");
                })
            }
        })
    },

    listSupport: function (req, res) {
        supportModule.listSupport(function (data) {
            res.send(data);
        })
    }

}