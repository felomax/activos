const modeloFModule = require("../models/modeloFirewall.model");

const conexion = require("../config/conexion");


module.exports = {


    addModeloF: async (req, res) => {
        const modelo = req.body.modelo;

        modeloFModule.addModeloF(modelo, function (data) {
            if (data != undefined) {
                return res.status(501).send("Modelo Firewall ya Registrado");
            } else {
                modeloFModule.addModeloF(modelo, function (data) {
                    return res.status(200).send("Modelo Firewall Registrado con éxito");
                })
            }
        })
    },

    deleteModeloF: function (req, res) {
        const id = req.params.id;
        modeloFModule.searchId(id, function (data) {
            if (data == undefined) {
                return res.status(501).send("Modelo Firewall No existe")
            } else {
                modeloFModule.deleteModeloF(id, function (data) {
                    return res.status(200).send("Modelo Firewall Eliminado con exito");
                })
            }
        })
    },

    editModeloF: async (req, res) => {
        const id = req.params.id;      
        const modelo = req.body.modelo;

        modeloFModule.searchId(id, function (data) {
            if (data == undefined) {
                return res.status(501).send("Modelo Firewall no existe")
            } else {
                modeloFModule.editModeloF(
                    id, modelo, function(data){
                        res.send(data);
                    }
                    )
            }
        })
    },

    listModeloF: function (req, res){
        modeloFModule.listModeloF(function (data){
            res.send(data);
        })
    }
}