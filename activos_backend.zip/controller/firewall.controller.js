const firewallModule = require("../models/firewall.model");
const conexion = require("../config/conexion");

module.exports = {

    addFirewall: async (req, res) => {
        const equipo = req.body.equipo;
        const model = req.body.model;
        const serial_number = req.body.serial_number;
        const ip_addr = req.body.ip_addr;
        const ubicacion = req.body.ubicacion;
        const version = req.body.version;
        const connected_to = req.body.connected_to;
        const activation_date = req.body.activation_date;
        const expire_date = req.body.expire_date;
        const license_type = req.body.license_type;
        const provider = req.body.provider;
        const state = req.body.state;

        firewallModule.searchFirewall(equipo, function (data) {
            if (data != undefined) {
                return res.status(501).send("Equipo ya se encuentra Registrado");
            } else {
                firewallModule.addFirewall(
                    equipo, model, serial_number, ip_addr, ubicacion, version, connected_to,
                    activation_date, expire_date, license_type, provider, state,
                    function (data) {
                        return res.status(200).send("Equipo registrado con exito");
                    })
            }
        })
    },

    editFirewall: async (req, res) => {
        const id = req.params.id;
        const equipo = req.body.equipo;
        const model = req.body.model;
        const serial_number = req.body.serial_number;
        const ip_addr = req.body.ip_addr;
        const ubicacion = req.body.ubicacion;
        const version = req.body.version;
        const connected_to = req.body.connected_to;
        const activation_date = req.body.activation_date;
        const expire_date = req.body.expire_date;
        const license_type = req.body.license_type;
        const provider = req.body.provider;
        const state = req.body.state;

        firewallModule.searchId(id, function (data) {
            if (data == undefined) {
                return res.status(501).send("Firewall no existe")
            } else {
                firewallModule.editFirewall(
                    id, equipo, model, serial_number, ip_addr, ubicacion, version, connected_to, activation_date, expire_date,
                    license_type, provider, state, function(data){
                        res.send(data);
                    }
                    )
            }
        })
    },

    deleteFirewall: function (req, res) {
        const id = req.params.id;
        firewallModule.searchId(id, function (data) {
            if (data == undefined) {
                return res.status(501).send("Firewall No existe")
            } else {
                firewallModule.deleteFirewall(id, function (data) {
                    return res.status(200).send("Firewall Eliminado con exito");
                })
            }
        })
    },

    listFirewall: function (req, res) {
        firewallModule.listFirewall(function (data) {
            res.send(data);
        })
    },


}