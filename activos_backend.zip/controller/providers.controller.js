const providersModule = require("../models/providers.models")

const conexion = require("../config/conexion");

module.exports = {

    addProviders: async (req, res) => {
        const provider = req.body.provider;

        providersModule.searchProvider(provider, function (data) {
            if (data != undefined) {
                return res.status(501).send("Proveedor ya Registrada");
            } else {
                providersModule.addProviders(provider, function (data) {
                    return res.status(200).send("Proveedor registrada con éxito")
                })
            }
        })
    },

    editProviders: async (req, res) => {
        const id = req.params.id;
        const provider = req.body.provider;

        providersModule.searchId(id, function (data) {
            if (data == undefined) {
                return res.status(501).send("Proveedor no existe")
            } else {
                providersModule.editProviders(
                    id, provider, function (data) {
                        res.send(data);
                    }
                )
            }
        })

    },

    deleteProviders: function (req, res) {
        const id = req.params.id;

        providersModule.searchId(id, function (data) {
            if (data == undefined) {
                return res.status(501).send("Proveedor no existe")
            } else {
                providersModule.deleteProviders(id, function (data) {
                    return res.status(200).send("Proveedor eliminado con exito");
                })
            }
        })
    },

    listProviders: function (req, res) {
        providersModule.listProviders(function (data) {
            res.send(data);
        })
    }

}