const graficoModuleNodes = require("../models/graficoNode.model");
const graficoModuleLinks = require("../models/graficoLink.model");
const conexion = require("../config/conexion");

module.exports = {

    listaGraficaNodes: function (req, res){
        graficoModuleNodes.listaGraficaNodes(function(data){
            res.send(data);
            console.log(data)
        })
    },

    listaGraficaLink: function (req, res){
        graficoModuleLinks.listaGraficaLinks(function(data){
            res.send(data);
        })
    }
}