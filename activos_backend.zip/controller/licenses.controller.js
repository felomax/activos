const licenseModule = require("../models/license.model")

const conexion = require("../config/conexion");

module.exports = {

    addLicences: async (req, res) => {
        const license = req.body.license;

        licenseModule.searchLicense(license, function (data) {
            if (data != undefined) {
                return res.status(501).send("Licencia ya Registrada");
            } else {
                licenseModule.addLicenses(license, function (data) {
                    return res.status(200).send("Liencia registrada con éxito")
                })
            }
        })
    },

    editLicense: async (req, res) => {
        const id = req.params.id;
        const license = req.body.license;

        licenseModule.searchId(id, function (data) {
            if (data == undefined) {
                return res.status(501).send("Licencia No existe")
            } else {
                licenseModule.editLicense(
                    id, license, function (data) {
                        res.send(data);
                    }
                )
            }
        })

    },

    deleteLicense: function (req, res) {
        const id = req.params.id;

        licenseModule.searchId(id, function (data) {
            if (data == undefined) {
                return res.status(501).send("Licencia no existe")
            } else {
                licenseModule.deleteLicense(id, function (data) {
                    return res.status(200).send("Licencia eliminada con exito");
                })
            }
        })
    },

    listLicenses: function (req, res) {
        licenseModule.listLicenses(function (data) {
            res.send(data);
        })
    }

}