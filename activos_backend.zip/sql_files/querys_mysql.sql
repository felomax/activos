select * from activos.firewall;


-- vista de consulta de equipos para el cdte pinaud
create or replace view consulta_equipos
as
SELECT f.id, f.equipo, m.modelo , f.serial_number, f.ip_addr, f.ubicacion, f.version, f.connected_to, f.activation_date , f.expire_date, l.license, p.provider, f.state
from activos.firewall f
join activos.modelo_firewall m
on  f.model = m.id
join activos.licenses l 
on f.license_type = l.id
join activos.providers p
on f.provider = p.id
order by p.id asc;


-- activador de programador de eventos en mysql
SET GLOBAL event_scheduler = ON;


-- Este evento programado actualiza una vez al dia los contratos de equipos a estado ATRASADO
CREATE event verificar_atrasado ON schedule every 1 DAY DO
UPDATE firewall SET 
state = 'atrasado'
WHERE DATE_FORMAT(expire_date, "%Y-%m-%d") < DATE_FORMAT(CURDATE(), "%Y-%m-%d");


-- Este evento programado actualiza una vez al dia los contratos de equipos a estado PROXIMO A VENCER.
CREATE event verificar_prox_30 ON schedule every 1 DAY DO
UPDATE firewall SET state = 'próximo a vencer'
where DATE_FORMAT(expire_date, "%Y-%m-%d") between now() and date_add(now(), interval 30 day);

drop event verificar_prox_30