const mysql = require('mysql2');
const conexion = mysql.createConnection({
    host: '192.168.27.54',
    user: 'activos',
    password: 'Difa.,2022+',
    port: 3306,
    database: 'activos'
});

conexion.connect((err) => {
    if (err) {
        console.log('Ha ocurrido un error' + err);

    } else {
        console.log('Conexión Exitosa');
    }
})

module.exports = conexion;