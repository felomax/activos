
const express = require("express");
const router = express.Router();
const controllerGraficos = require ("../controller/grafico.controller");


 
router.use(function (res, req, next) {
    res.header(
        "Access-Control-Allow-Headers",
        "x-access-token, Origin, Content-Type, Accept"
    );
    next();
});

router.get("/listGraficosNodes", controllerGraficos.listaGraficaNodes);
router.get("/listGraficosLinks", controllerGraficos.listaGraficaLink);


module.exports = router;