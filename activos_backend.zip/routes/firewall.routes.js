const router = require("./user.routes");
const controllerFirewall = require("../controller/firewall.controller");


router.post("/addFirewall", controllerFirewall.addFirewall);
router.get("/deleteFirewall/:id", controllerFirewall.deleteFirewall);
router.put("/editFirewall/:id", controllerFirewall.editFirewall);
router.get("/listFirewall", controllerFirewall.listFirewall);





module.exports = router;