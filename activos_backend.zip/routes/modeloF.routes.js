const express = require("express");
const router = express.Router();
const controllerModeloF = require ("../controller/modeloFirewall.controller");

router.use(function (res, req, next) {
    res.header(
        "Access-Control-Allow-Headers",
        "x-access-token, Origin, Content-Type, Accept"
    );
    next();
});


router.post("/addModeloF", controllerModeloF.addModeloF);
router.put("/editModeloF/:id", controllerModeloF.editModeloF);
router.get("/deleteModeloF/:id", controllerModeloF.deleteModeloF)
router.get("/listModeloF", controllerModeloF.listModeloF);


module.exports = router;