const express = require("express");
const router = express.Router();
const controllerProviders = require("../controller/providers.controller");


router.post("/addProviders", controllerProviders.addProviders);
router.get("/deleteProviders/:id", controllerProviders.deleteProviders)
router.put("/editProviders/:id", controllerProviders.editProviders);
router.get("/listProviders", controllerProviders.listProviders);


module.exports = router;