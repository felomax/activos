const express = require("express");
const router = express.Router();
const controllerLicences = require("../controller/licenses.controller");


router.post("/addLicences", controllerLicences.addLicences);
router.get("/deleteLicense/:id", controllerLicences.deleteLicense)
router.put("/editLicense/:id", controllerLicences.editLicense);
router.get("/listLicenses", controllerLicences.listLicenses);




 module.exports = router;