const express = require("express");
const router = express.Router();
const controllerSupport = require("../controller/support.controller");


 router.post("/addSupport", controllerSupport.addSupport);
router.get("/deleteSupport/:id", controllerSupport.deleteSupport);
 router.put("/editSupport/:id", controllerSupport.editSupport);
router.get("/listSupport", controllerSupport.listSupport);


module.exports = router;