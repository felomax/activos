import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSidenavModule } from '@angular/material/sidenav';
import { AddUsersComponent } from 'src/app/modules/users/add-users/add-users.component';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent implements OnInit {

  currentPersonal?: {};
  currentIndex = -1;
  constructor( private dialog: MatDialog,) { }

  ngOnInit(): void {
  }

  addUser() {
    this.dialog
      .open(AddUsersComponent, {
        width: '50%',
      })
      .afterClosed()
      .subscribe((val) => {
        if (val === 'Registrar Usuario') {
          this.refreshList();
        }
      });
  }

  refreshList(): void {
    window.location.reload();
    this.currentPersonal = {};
    this.currentIndex = -1;
  }

}
