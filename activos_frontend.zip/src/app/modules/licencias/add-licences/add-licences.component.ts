import { Component, OnInit } from '@angular/core';
import { UntypedFormGroup } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { NgToastService } from 'ng-angular-popup';

@Component({
  selector: 'app-add-licences',
  templateUrl: './add-licences.component.html',
  styleUrls: ['./add-licences.component.css']
})
export class AddLicencesComponent implements OnInit {
  formAgLicence !: UntypedFormGroup;
  hide = true;

  constructor( private toast: NgToastService,
    private router: Router,
    private dialogRef: MatDialogRef<AddLicencesComponent>,) { }

  ngOnInit(): void {
  }

  addLicence() {
    // if (this.formAgLicence.valid) {
    //   this.usuarioService.addUser(this.formAgLicence.value)
    //     .subscribe({
    //       next: (res) => { },
    //       error: (err) => {
    //         if (err.status === 200) {
    //           this.toast.success({
    //             detail: "Usuario registrado",
    //             summary: "Usuario registrado con exito",
    //             duration: 3000,
    //             position: 'br'
    //           })

    //           this.formAgLicence.reset();
    //           this.dialogRef.close('Registrar Usuario')


    //         } else {
    //           this.toast.error({
    //             detail: "Atención",
    //             summary: "Personal ya se encuentra Registrado",
    //             duration: 3000,
    //             position: 'br'
    //           })
    //         }

    //       }

    //     })
    // }
  }

  cancelar() {
    this.toast.warning({
      detail: "Atención",
      summary: "Acción Cancelada",
      duration: 3000,
      position: 'br'
    })
    this.router.navigate(['/listarUsuarios']);
  }

}


