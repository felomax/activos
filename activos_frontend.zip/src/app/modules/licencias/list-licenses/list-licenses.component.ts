import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Observable } from 'rxjs';
import { Licenses } from 'src/app/models/licenses';
// import { EquiposService } from 'src/app/services/equipos.service';
import { LicensesService } from 'src/app/_services/licenses.service';


@Component({
  selector: 'app-list-licenses',
  templateUrl: './list-licenses.component.html',
  styleUrls: ['./list-licenses.component.css']
})
export class ListLicensesComponent implements OnInit {
 
  row: any;
  listEquipos!: Observable<Licenses[]>;

  displayedColumns: string[] = [
    'id',
    'license'
  ];

  dataSource!: MatTableDataSource<any>;

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  constructor(private licensesService: LicensesService) { }

  ngOnInit(): void {

    this.loadingEquipos();
    this.licensesService.listLicenses().subscribe((res) => {
      console.log(res[1]['license'])
      this.dataSource = new MatTableDataSource(res);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    })
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLocaleLowerCase();
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  loadingEquipos() {
    this.listEquipos = this.licensesService.listLicenses();
  }

}
