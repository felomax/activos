import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgToastService } from 'ng-angular-popup';
import { Subscription } from 'rxjs';
import { Options } from 'highcharts';
import { GraficosService } from '../../_services/graficos.service'
import { FirewallGraph } from '../../models/firewallGraph';

import { Chart } from 'angular-highcharts';

import * as Highcharts from 'highcharts';
import HC_networkgraph from 'highcharts/modules/networkgraph';
HC_networkgraph(Highcharts);



HC_networkgraph(Highcharts);


@Component({
  selector: 'app-graficas',
  templateUrl: './graficas.component.html',
  styleUrls: ['./graficas.component.scss']
})

export class GraficasComponent implements OnInit {

  Highcharts: typeof Highcharts = Highcharts;
  highChart!: Highcharts.Chart | null;


  update = false;
  show = false;
  timerSubscription!: Subscription;

  constructor(private grafico: GraficosService) { }


  ngOnInit() {
    this.listarNavegador();
  }

  async listarNavegador() {
    this.grafico.listNodes().subscribe((data: FirewallGraph[]) => {
      
      
      this.navegador15.series = [
        {             
          type: 'networkgraph',
          data: data.map(e =>[e.from,e.to])
        }
      ]
      console.log(this.navegador15.series)
    });
  }























  navegador15: Highcharts.Options = {
    title: {
      text: 'GRAFICO DE PRUEBA'
    },
    chart: {
      type: 'networkgraph',
      inverted: false
    },
    plotOptions: {
      networkgraph: {
        keys: ['from','to'],
        layoutAlgorithm: {
          enableSimulation: true,
          linkLength: 45
        }
      }
    },
    tooltip: {
      outside: true
    },
    series: [
      {
        name: 'ogoeoger',
        type: 'networkgraph',
        dataLabels: {
          enabled: true,
          allowOverlap: true,
          format: 'Node: {point.name}',
          linkFormat: '{point.fromNode.name} \u2192 {point.toNode.name}',
          linkTextPath: {
            attributes: {
              dy: 12
            }
          },
          textPath: {
            enabled: true,
            attributes: {
              dy: 3,
              startOffset: '40%',
              textLength: 80
            },
          }
        },
        marker: {
          radius: 40,
          symbol: 'url(https://cdn-icons-png.flaticon.com/128/6056/6056215.png)',
          
        },
        data: [
        {
          from: '192.168.27.56',
          to: '192.168.27.59',
        }],
      }]
  };


  // async ngAfterContentInit() {
  //   this.listarNavegador()
  //   .then(async son =>{
  //     await this.listarNavegador();
  //     return son;
  //   });
  //   setTimeout(() => {

  //     this.listarNavegador();
  
  //   }, 2000);
  
  // }





}
