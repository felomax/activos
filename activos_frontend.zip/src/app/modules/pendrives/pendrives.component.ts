import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Observable } from 'rxjs';
import { Pendrives } from 'src/app/models/pendrives';
import { PendrivesService } from 'src/app/_services/pendrives.service';


@Component({
  selector: 'app-pendrives',
  templateUrl: './pendrives.component.html',
  styleUrls: ['./pendrives.component.css']
})
export class PendrivesComponent implements OnInit {

  
  row: any;
  listEquipos!: Observable<Pendrives[]>;

  displayedColumns: string[] = [
    'id',
    'restriccion',
    'grado',
    'nombre',
    'apellidos',
    'numero_dispositivo',
    'fecha_entrega',
    'correo',
    'pendrivescol',
    'device_type',
    'hardware_id',
    'serial',
    'version',
    'estado',
  ];

  dataSource!: MatTableDataSource<any>;

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  constructor(private pendriveService: PendrivesService,) { }

  ngOnInit(): void {

    this.loadingEquipos();
    this.pendriveService.listPendrives().subscribe((res) => {
      
      this.dataSource = new MatTableDataSource(res);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    })
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLocaleLowerCase();
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  loadingEquipos() {
    this.listEquipos = this.pendriveService.listPendrives();
  }


}
