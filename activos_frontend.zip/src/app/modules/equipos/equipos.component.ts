import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Observable } from 'rxjs';
import { Equipos } from 'src/app/models/equipos';
import { EquiposService } from 'src/app/_services/equipos.service';

@Component({
  selector: 'app-activos',
  templateUrl: './equipos.component.html',
  styleUrls: ['./equipos.component.css']
})
export class ActivosComponent implements OnInit {

  row: any;
  listEquipos!: Observable<Equipos[]>;

  displayedColumns: string[] = [
    'id',

    'model',
    'serial_number',
    'equipo',
    'ip_addr',
    'ubicacion',
    'version',
    'connected_to',
    'activation_date',
    'expire_date',
    'license',
    'provider',
    'state',
    'acciones',
  ];

  dataSource!: MatTableDataSource<any>;

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  constructor(private equiposServices: EquiposService,) { }

  ngOnInit(): void {

    this.loadingEquipos();
    this.equiposServices.listEquipos().subscribe((res) => {
      console.log(res[1]['expire_date'])
      this.dataSource = new MatTableDataSource(res);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    })
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLocaleLowerCase();
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  loadingEquipos() {
    this.listEquipos = this.equiposServices.listEquipos();
  }

}
