import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-equipos',
  templateUrl: './add-equipos.component.html',
  styleUrls: ['./add-equipos.component.css']
})
export class AddEquiposComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
