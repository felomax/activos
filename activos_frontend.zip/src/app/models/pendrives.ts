
export interface Pendrives {

    restriccion?: any;
    grado?: any;
    nombre?: any;
    apellidos?: any;
    numero_dispositivo?: any;
    fecha_entrega?: any;
    correo?: any;
    pendrivescol?: any;
    device_type?: any;
    hardware_id?: any;
    serial?: any;
    version?: any;
    estado?: any;

}