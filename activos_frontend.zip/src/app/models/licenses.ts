
export interface Licenses{

    license?:any;
    
}