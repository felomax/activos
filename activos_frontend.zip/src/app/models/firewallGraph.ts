
export interface FirewallGraph{

    from?: any;
    to?: any;
    
}