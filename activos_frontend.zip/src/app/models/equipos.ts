
export interface Equipos{

    equipo?: any;
    model?: any;
    serial_number?: any;
    ip_addr?: any;
    ubicacion?: any;
    version?: any;
    connected_to?: any;
    activaction_date?: any;
    expire_date?: any;
    license_type?: any;
    
}