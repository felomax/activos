export interface Users {
    id_user?: any;
    apellido?: any;
    nombre?: any;
    email?: any;
    password?: any;
    rol?: any;
  }
  
  export interface Usuario {
    email: string;
    password: any;
  }
  
  export interface Password{
    password:any;
  }