import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Pendrives } from '../models/pendrives';

@Injectable({
  providedIn: 'root'
})
export class PendrivesService {

  private URL = environment.URL;


  constructor(private http: HttpClient) {}

  listPendrives(){
    return this.http.get<Pendrives[]>(this.URL + '/listPendrivers')      
  }

}
